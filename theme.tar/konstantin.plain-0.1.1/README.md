# Plain theme

Minimalist plain theme for vscode

## Installation

<kbd>Ctrl</kbd> + <kbd>Shift</kbd> + <kbd>P</kbd> on Windows/Linux → `ext install konstantin.plain`

or

<kbd>⌘</kbd> + <kbd>⇧</kbd> + <kbd>P</kbd> on macOS → `ext install konstantin.plain`

## Screenshot

![screenshot](https://github.com/gko/plain/raw/master/screenshot.png)

with status bar and activity bar:

![screenshot2](https://github.com/gko/plain/raw/master/screenshot2.png)

dark version:

![dark version](https://github.com/gko/plain/raw/master/screenshot-dark.png)
